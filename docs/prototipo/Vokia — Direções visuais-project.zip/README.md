# Vokia — Direções visuais — entire project

This project’s pages, files, and uploads as this browser tab had them at export.
Anything left out is listed below.

## Contents

- `Agentes.dc.html`
- `ArtADR.dc.html`
- `ArtCasos.dc.html`
- `ArtDocumento.dc.html`
- `ArtMermaid.dc.html`
- `ArtNotas.dc.html`
- `ArtPlantUML.dc.html`
- `Artefatos.dc.html`
- `Atividade.dc.html`
- `AtividadeSistema.dc.html`
- `BacklogCard.dc.html`
- `BacklogCompacto.dc.html`
- `BacklogComponentes.dc.html`
- `BacklogModal.dc.html`
- `BacklogPlano.dc.html`
- `BarraAcao.dc.html`
- `BarraV2.dc.html`
- `BarraV2NoApp.dc.html`
- `BarraV2Prototipo.dc.html`
- `BarraV3.dc.html`
- `Canvas.dc.html`
- `Conversas.dc.html`
- `ConversasProposta.dc.html`
- `ConversasV2.dc.html`
- `Design.dc.html`
- `DesktopTray.dc.html`
- `Diff.dc.html`
- `Dock.dc.html`
- `Estatisticas.dc.html`
- `FeatureReplay.dc.html`
- `ForaBandeja.dc.html`
- `ForaBarraTarefas.dc.html`
- `ForaLateral.dc.html`
- `Gastos.dc.html`
- `Gota.dc.html`
- `GotaVariacao.dc.html`
- `GotasFamilia.dc.html`
- `Identidades.dc.html`
- `LimitesComponentes.dc.html`
- `Main.dc.html`
- `Marca.dc.html`
- `Memoria.dc.html`
- `NovoProjeto.dc.html`
- `NovoProjetoPedido.dc.html`
- `NovoProjetoTime.dc.html`
- `OnbBoasVindas.dc.html`
- `OnbConexoes.dc.html`
- `OnbPedido.dc.html`
- `OnbPronto.dc.html`
- `OnbTime.dc.html`
- `Onboarding.dc.html`
- `Orquestracao.dc.html`
- `PedidoAprovado.dc.html`
- `PedidoClassificando.dc.html`
- `PedidoComponentes.dc.html`
- `PedidoDevolvido.dc.html`
- `PedidoEnviado.dc.html`
- `PedidoEscrever.dc.html`
- `PedidoFeature.dc.html`
- `PedidoNovo.dc.html`
- `PedidoPequeno.dc.html`
- `PedidoPerguntas.dc.html`
- `PedidoProposta.dc.html`
- `PedidoTriagem.dc.html`
- `PilotoBacklog.dc.html`
- `Plano.dc.html`
- `PlanoVinculo.dc.html`
- `Projetos.dc.html`
- `ProjetosV2.dc.html`
- `Retrato.dc.html`
- `Sidebar.dc.html`
- `Skills.dc.html`
- `canvas.json` — the canvas: its pages, where each artboard sits, its notes and shapes
- `_runtime/` — what runs the pages in a browser; not part of the design

## Viewing

To view a page, start a local web server in this folder (for example `python3 -m http.server`), then open an artboard’s `.dc.html` file through it. Opening the file directly may not work, because some browsers block its scripts.

## Left out of this export

The export never includes hidden files (files whose names start with a dot) or
files the editor keeps for its own use.
